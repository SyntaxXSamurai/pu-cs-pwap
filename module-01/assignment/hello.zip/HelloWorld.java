public class HelloWorld {
	public static void main(String[] args) {
		// Print out "Hello World"
		System.out.println("Hello World");
	}
}